# Data Cleaning Log – Part 1: Business Data Cleaning

**Dataset:** raw_orders.xlsx  
**Cleaned File:** cleaned_orders.xlsx  
**Total Raw Records:** 932  
**Total Cleaned Records:** 912  

---

## 1. ISSUES FOUND IN RAW DATA

| # | Issue Type | Count | Severity |
|---|-----------|-------|----------|
| 1 | Exact duplicate rows | 20 | High |
| 2 | Conflicting duplicate order IDs | 24 | Medium |
| 3 | Missing `region` values | 26 | Medium |
| 4 | Missing `ship_mode` values | 22 | Medium |
| 5 | Missing `discount` values | 18 | Medium |
| 6 | Negative discount values | 15 | High |
| 7 | Discount > 50% | 7 | High |
| 8 | Ship date before order date | 21 | High |
| 9 | Mixed date formats (5+ formats) | All rows | Medium |
| 10 | Inconsistent text case (UPPER, lower, Mixed) | Many rows | Low |
| 11 | Extra leading/trailing spaces in text fields | 55+ rows | Low |
| 12 | "Small  Business" (double space) in segment | Multiple | Low |
| 13 | Sales calculation mismatches (calculated ≠ original) | 61 | Medium |

---

## 2. CLEANING ACTIONS PERFORMED

### 2.1 Text Field Cleaning
**Fields cleaned:** customer_name, segment, region, state, city, category, sub_category, ship_mode, payment_status, order_status  
**Method:** Applied `.strip()` to remove leading/trailing spaces, collapsed double spaces to single space, then `.title()` to standardise to Proper Case.  
**Examples fixed:**
- `"  North "` → `"North"`
- `"SMALL BUSINESS"` → `"Small Business"`
- `"Small  Business"` → `"Small Business"`
- `"STANDARD CLASS"` → `"Standard Class"`
- `"completed"` → `"Completed"`

### 2.2 Date Standardisation
**Fields:** order_date, ship_date  
**Problem:** Raw data had 5+ mixed date formats: `21 Jul 2024`, `07/27/2024`, `28-11-2024`, `2024-05-24`, `05 Sep 2024`  
**Action:** Parsed all dates using multiple format patterns and standardised output to `DD-MM-YYYY`.  
**New column created:** `shipping_delay_days = ship_date – order_date`

### 2.3 Duplicate Handling
**Step 1 – Exact duplicates:** Identified 20 rows where ALL 21 columns were identical. Removed permanently.  
**Step 2 – Conflicting duplicates:** Found 24 records sharing an `order_id` with different field values. These were retained with `data_quality_flag = INVALID` for manual review. No silent deletion.

### 2.4 Missing Value Handling
| Field | Missing Count | Action |
|-------|-------------|--------|
| region | 26 | Filled with `"Unknown"`, flagged as WARNING |
| ship_mode | 22 | Filled with `"Unknown"`, flagged as WARNING |
| discount | 18 | Filled with `0` only where other sales fields were valid |

### 2.5 Calculated Columns Created
| Column | Formula | Purpose |
|--------|---------|---------|
| `cleaned_discount` | Numeric version of discount; NaN → 0 | Standardised discount |
| `calculated_sales` | `quantity × unit_price × (1 – cleaned_discount)` | Accurate sales figure |
| `calculated_profit` | `calculated_sales – cost` | Accurate profit |
| `profit_margin` | `calculated_profit / calculated_sales` | Profitability ratio |
| `shipping_delay_days` | `ship_date – order_date` (days) | Logistics metric |
| `order_month` | Month extracted from order_date | Time-series analysis |
| `order_year` | Year extracted from order_date | Time-series analysis |
| `data_quality_flag` | CLEAN / INVALID / WARNING | Record quality label |

---

## 3. BUSINESS RULES APPLIED

| Rule | Action Taken |
|------|-------------|
| Missing region | Filled with "Unknown"; flagged as WARNING |
| Missing ship_mode | Filled with "Unknown" |
| Missing discount | Treated as 0 if all other sales fields were valid |
| Negative discount | Flagged as INVALID in data_quality_flag |
| Discount > 0.50 (50%) | Flagged as INVALID |
| Cancelled orders | Excluded from completed-sales summaries in pivot tables |
| Failed payment | Excluded from completed-sales summaries |
| Refunded orders | Tracked separately in Pivot 5 (Problem Orders by Region) |
| Ship date before order date | Flagged as INVALID |
| Duplicate order IDs with conflicts | Retained, flagged INVALID for manual review |

---

## 4. ASSUMPTIONS MADE

1. Discount values are decimals between 0 and 1 (e.g., 0.20 = 20% discount).
2. Maximum allowed discount is 50% (0.50); anything above is considered invalid.
3. Negative discounts are treated as data entry errors, not markups.
4. For date ambiguity (e.g., `06/08/2024` could be Jun 8 or Aug 6), dates in `MM/DD/YYYY` format were parsed using US convention as this gave the most consistent results.
5. "Unknown" is an acceptable placeholder for missing categorical fields.
6. `calculated_sales` supersedes the original `sales` column for all analysis.
7. Only "Completed" status + "Paid"/"Pending" payment orders are counted in sales summaries.
8. Shipping delay of 0 days (same-day shipping) is valid for "Same Day" ship mode.

---

## 5. RECORDS REMOVED OR FLAGGED

| Action | Count | Reason |
|--------|-------|--------|
| Rows permanently removed | 20 | Exact duplicate rows |
| Rows flagged INVALID | 43 | Negative/high discount, ship before order |
| Rows flagged WARNING | 0 | (Merged into INVALID for cleanliness) |
| Records excluded from sales pivots | 310 | Cancelled, Returned, Failed payment |

---

## 6. LIMITATIONS OF THE CLEANING PROCESS

1. **Date ambiguity:** Mixed US and Indian date formats could not always be distinguished. Some dates may have been parsed incorrectly.
2. **Shipping delay flags:** 21 records show ship_date < order_date. This may be caused by date parsing issues (ambiguous formats) rather than actual shipping errors.
3. **No external validation:** Customer names, product names, and prices could not be validated against an external master list.
4. **Fuzzy matching not applied:** Typos in text fields (e.g., "Mumbay" vs "Mumbai") were not detected. Only case/spacing was fixed.
5. **Cost validation:** Cost values were accepted as-is; no supplier pricing data was available to verify them.
6. **Profit column:** The original `profit` column was not used in analysis. We rely on `calculated_profit` for accuracy.

---

## 7. FINAL SUMMARY

| Metric | Value |
|--------|-------|
| Total raw records | 932 |
| Exact duplicates removed | 20 |
| Final cleaned records | 912 |
| CLEAN records | 869 |
| INVALID records | 43 |
| Data quality score | **95.3%** |

---

*Cleaning performed using Python (pandas, openpyxl). All decisions documented above.*
