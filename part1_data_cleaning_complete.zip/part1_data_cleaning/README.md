# Part 1: Business Data Cleaning, Validation & Excel Reporting

## Problem Summary
This project cleans and validates raw retail order-level sales data exported from multiple internal systems. The raw file contains mixed date formats, inconsistent text formatting, duplicate records, missing values, invalid discounts, order status issues, and sales/profit calculation mismatches.

The objective is to preserve the original raw data, create an analysis-ready cleaned dataset, document all quality issues, and build Excel summary reports for business review.

## Repository Structure

```text
part1_data_cleaning/
├── data/
│   ├── raw_orders.xlsx
│   └── cleaned_orders.xlsx
├── outputs/
│   ├── data_quality_report.xlsx
│   ├── pivot_summary.xlsx
│   └── cleaning_log.md
├── screenshots/
│   ├── raw_data_preview.png
│   ├── cleaned_data_preview.png
│   ├── pivot_summary_1.png
│   └── pivot_summary_2.png
└── README.md
```

## Dataset Description
The dataset contains order-level retail sales records with fields such as order ID, order date, ship date, customer details, region, state, city, product category, sub-category, ship mode, payment status, order status, discount, quantity, unit price, cost, sales, and profit.

The original file is kept unchanged as:

`data/raw_orders.xlsx`

The cleaned and validated file is saved separately as:

`data/cleaned_orders.xlsx`

## Tools Used
- Microsoft Excel
- Python for structured cleaning support
- pandas-style data validation logic
- Excel formulas and pivot-style reporting
- Markdown documentation

## Cleaning Steps Performed

### 1. Raw Data Preservation
The original dataset was preserved without modification in `data/raw_orders.xlsx`. All cleaning work was completed in the separate cleaned file.

### 2. Text Cleaning
The following fields were standardized:

- customer_name
- segment
- region
- state
- city
- category
- sub_category
- ship_mode
- payment_status
- order_status

Actions performed:

- Removed leading and trailing spaces
- Removed extra internal double spaces
- Standardized text case to readable proper case
- Standardized similar category/segment names
- Replaced missing region and ship mode values with `Unknown`

### 3. Date Cleaning and Validation
The `order_date` and `ship_date` fields had multiple formats such as text dates, slash dates, dash dates, and ISO-style dates. Dates were parsed and standardized into a consistent format.

A calculated column was added:

`shipping_delay_days = ship_date - order_date`

Records were flagged where:

- order date was missing or invalid
- ship date was missing or invalid
- ship date was earlier than order date

### 4. Duplicate Handling
The duplicate review identified:

- Exact duplicate rows
- Duplicate order IDs with conflicting information

Exact duplicate rows were removed. Conflicting duplicate order IDs were not silently deleted; they were retained and flagged for review.

### 5. Missing Value Handling
Business rules applied:

- Missing region → filled as `Unknown` and flagged
- Missing ship mode → filled as `Unknown` and flagged
- Missing discount → treated as 0 only when other sales fields were valid

### 6. Business Rule Validation
The following records were flagged as invalid or excluded from final completed-sales summaries where required:

- Negative discount
- Discount greater than 50%
- Cancelled orders
- Failed payments
- Refunded/returned orders
- Ship date before order date
- Duplicate order IDs with conflicting information

## Calculated Columns Added
The cleaned dataset includes the following calculated columns:

| Column | Purpose |
|---|---|
| cleaned_discount | Standardized numeric discount value |
| calculated_sales | Sales recalculated using quantity, unit price, and cleaned discount |
| calculated_profit | Profit recalculated using calculated sales and cost |
| profit_margin | Profit divided by sales |
| shipping_delay_days | Days between order date and ship date |
| order_month | Month extracted from order date |
| order_year | Year extracted from order date |
| data_quality_flag | CLEAN / WARNING / INVALID record status |

## Data Quality Issues Found

| Issue Type | Count |
|---|---:|
| Total raw records | 932 |
| Exact duplicate rows | 20 |
| Final cleaned records | 912 |
| Conflicting duplicate order ID records | 24 |
| Missing region values | 26 |
| Missing ship mode values | 22 |
| Missing discount values | 18 |
| Negative discount values | 15 |
| Discount above allowed range | 7 |
| Ship date before order date | 21 |
| Sales calculation mismatches | 61 |
| Invalid records flagged | 43 |
| Clean records | 869 |

## Pivot Reports Created
The file `outputs/pivot_summary.xlsx` contains the following reporting sheets:

1. Sales and profit by region
2. Sales and profit by category and sub-category
3. Order count by ship mode
4. Profit margin by customer segment
5. Refunded/cancelled/failed orders by region
6. Monthly sales trend
7. Dashboard summary

At least two summaries include sorting/filtering logic, including region sales sorted by total sales and problem-order reporting separated by status.

## Key Business Insights
- South has the highest total completed sales among regions.
- West and East show stronger profit margin performance than South.
- February is the strongest sales month in the monthly trend.
- November and December show lower order volume and should be reviewed for seasonal or operational reasons.
- Cancelled, returned/refunded, and failed-payment records must be excluded from final completed-sales summaries.
- Discount and shipping-date issues are the most important invalid-record drivers.

## Assumptions and Limitations
- Discount values are stored as decimals, where 0.20 means 20%.
- Discount above 50% is considered invalid.
- Negative discount is treated as a data-entry error.
- Ambiguous dates were parsed using the most consistent interpretation across the dataset.
- `Unknown` is used as a placeholder for missing region and ship mode values.
- `calculated_sales` and `calculated_profit` are used for reporting instead of original sales/profit when mismatches exist.
- No external master data was available to validate customer names, product names, cost, or state/city spelling.

## Screenshots Included
- `screenshots/raw_data_preview.png` — raw dataset before cleaning
- `screenshots/cleaned_data_preview.png` — cleaned dataset with calculated columns
- `screenshots/pivot_summary_1.png` — region-level pivot summary
- `screenshots/pivot_summary_2.png` — monthly sales trend pivot summary

## Final Submission Note
Upload this folder to a separate GitHub repository named using the required format:

`studentname_studentid_part1_data_cleaning`

Example:

`rahulsharma_12345_part1_data_cleaning`
